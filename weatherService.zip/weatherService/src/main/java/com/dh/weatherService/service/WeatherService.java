package com.dh.weatherService.service;

public interface WeatherService {
    Integer getTemperature(String city, String country);
}
