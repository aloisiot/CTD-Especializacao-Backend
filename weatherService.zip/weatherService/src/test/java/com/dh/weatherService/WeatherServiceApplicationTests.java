package com.dh.weatherService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WeatherServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
